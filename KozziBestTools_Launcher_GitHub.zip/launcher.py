import json
import os
import subprocess
import sys
import threading
import time
import urllib.request
import urllib.error
import tkinter as tk
from tkinter import messagebox

API_URL = "https://my-app-w063.onrender.com/api/check_license"
APP_FILENAME = "KozziBestTools.exe"
CHECK_EVERY_SECONDS = 180

def app_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def check_license(key):
    payload = json.dumps({"license_key": key}).encode("utf-8")
    req = urllib.request.Request(
        API_URL, data=payload,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=25) as response:
            data = json.loads(response.read().decode("utf-8"))
            return bool(data.get("valid")), data
    except urllib.error.HTTPError as e:
        try:
            data = json.loads(e.read().decode("utf-8"))
            return False, data
        except Exception:
            return False, {"reason": f"Сервер вернул ошибку {e.code}"}
    except Exception as e:
        return False, {"reason": f"Не удалось связаться с сервером: {e}"}

class Launcher:
    def __init__(self, root):
        self.root = root
        self.root.title("KozziBestTools — Активация")
        self.root.geometry("430x270")
        self.root.resizable(False, False)
        self.root.configure(bg="#111827")
        self.process = None
        self.key = ""

        tk.Label(root, text="KozziBestTools", bg="#111827", fg="white",
                 font=("Segoe UI", 20, "bold")).pack(pady=(24, 6))
        tk.Label(root, text="Введите ключ доступа", bg="#111827", fg="#cbd5e1",
                 font=("Segoe UI", 10)).pack(pady=(0, 12))
        self.entry = tk.Entry(root, width=38, font=("Segoe UI", 12),
                              justify="center", bg="#1f2937", fg="white",
                              insertbackground="white", relief="flat")
        self.entry.pack(ipady=9, padx=28)
        self.status = tk.Label(root, text="Лицензия проверяется на сервере",
                               bg="#111827", fg="#9ca3af", font=("Segoe UI", 9))
        self.status.pack(pady=12)
        self.button = tk.Button(root, text="ПРОВЕРИТЬ И ЗАПУСТИТЬ",
                                command=self.start, bg="#7c3aed", fg="white",
                                activebackground="#6d28d9", activeforeground="white",
                                relief="flat", font=("Segoe UI", 10, "bold"),
                                cursor="hand2")
        self.button.pack(ipadx=16, ipady=10, pady=3)
        self.root.protocol("WM_DELETE_WINDOW", self.close)

    def set_status(self, text, color="#9ca3af"):
        self.status.config(text=text, fg=color)

    def start(self):
        key = self.entry.get().strip()
        if not key:
            messagebox.showwarning("Нужен ключ", "Введите ключ доступа.")
            return
        self.key = key
        self.button.config(state="disabled")
        self.set_status("Проверяем ключ…", "#fbbf24")
        threading.Thread(target=self._check_then_launch, daemon=True).start()

    def _check_then_launch(self):
        valid, data = check_license(self.key)
        self.root.after(0, lambda: self._handle_initial(valid, data))

    def _handle_initial(self, valid, data):
        self.button.config(state="normal")
        if not valid:
            self.set_status(data.get("reason", "Ключ недействителен"), "#f87171")
            messagebox.showerror("Доступ запрещён",
                                 data.get("reason", "Ключ недействителен или срок истёк."))
            return
        exe = os.path.join(app_dir(), APP_FILENAME)
        if not os.path.isfile(exe):
            self.set_status("Не найден файл " + APP_FILENAME, "#f87171")
            messagebox.showerror("Нет приложения",
                                 f"Положите {APP_FILENAME} рядом с лаунчером.")
            return
        try:
            self.process = subprocess.Popen([exe], cwd=app_dir())
        except Exception as e:
            messagebox.showerror("Ошибка запуска", str(e))
            return
        self.set_status("Лицензия подтверждена. Приложение запущено.", "#34d399")
        self.button.config(text="ПРИЛОЖЕНИЕ ЗАПУЩЕНО", state="disabled")
        threading.Thread(target=self.monitor, daemon=True).start()

    def monitor(self):
        while self.process and self.process.poll() is None:
            time.sleep(CHECK_EVERY_SECONDS)
            if self.process.poll() is not None:
                break
            valid, data = check_license(self.key)
            if not valid:
                try:
                    self.process.terminate()
                except Exception:
                    pass
                reason = data.get("reason", "Лицензия больше недействительна")
                self.root.after(0, lambda r=reason: self._revoked(r))
                break

    def _revoked(self, reason):
        self.set_status("Доступ прекращён", "#f87171")
        messagebox.showerror("Лицензия недействительна",
                             reason + "\nПриложение закрыто.")

    def close(self):
        # Закрытие окна лаунчера не завершает приложение; мониторинг живёт
        # в процессе лаунчера, поэтому окно сворачивается/прячется.
        if self.process and self.process.poll() is None:
            self.root.withdraw()
        else:
            self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    Launcher(root)
    root.mainloop()
